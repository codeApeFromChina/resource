@ParentPackage("person")
@Namespace("/person") package org.apache.struts2.showcase.person;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

